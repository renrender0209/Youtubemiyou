import axios from 'axios';

// Initial set of Invidious API endpoints directly hardcoded from the GitHub repository
let apis = [
  "https://lekker.gay",
  "https://pol1.iv.ggtyler.dev",
  "https://cal1.iv.ggtyler.dev",
  "https://nyc1.iv.ggtyler.dev",
  "https://invidious.f5.si",
  "https://invidious.dhusch.de",
  "https://invidious.lunivers.trade",
  "https://iv.ggtyler.dev",
  "https://eu-proxy.poketube.fun",
  "https://invidious.reallyaweso.me",
  "https://yewtu.be",
  "https://usa-proxy2.poketube.fun",
  "https://id.420129.xyz",
  "https://invidious.materialio.us",
  "https://iv.melmac.space"
];

// Invidious APIの標準エンドポイントパス
const INVIDIOUS_VIDEO_PATH = '/api/v1/videos/';

const MAX_API_WAIT_TIME = 3000; 
const MAX_TIME = 10000;

// Function to get the API instances
function getApiInstances() {
  return apis;
}

// Attempt to update the list of APIs from GitHub on startup
(async function initApis() {
  try {
    const response = await axios.get('https://raw.githubusercontent.com/wakame02/wktopu/refs/heads/main/inv.json');
    if (response.data && Array.isArray(response.data) && response.data.length > 0) {
      apis = response.data;
      console.log('APIs fetched from GitHub:', apis);
    }
  } catch (error) {
    console.error('Failed to fetch APIs from GitHub during init:', error.message);
    // Keep using the hardcoded list
  }
})();

async function getapis() {
    try {
        const response = await axios.get('https://wtserver.glitch.me/apis');
        apis = await response.data;
        console.log('APIs fetched successfully:', apis);
    } catch (error) {
        console.error('Failed to fetch APIs:', error);
    }
}

async function getapisgit() {
    try {
        const response = await axios.get('https://raw.githubusercontent.com/wakame02/wktopu/refs/heads/main/inv.json');
        apis = await response.data;
        console.log('APIs fetched from GitHub:', apis);
    } catch (error) {
        console.error('Failed to fetch APIs from GitHub:', error);
    }
}

/**
 * ユーザー指定の形式で動画データを処理する関数
 * @param {object} apiResponse - APIからのレスポンスデータ
 * @returns {object} - 加工された動画情報
 */
function processInvidiousData(apiResponse, videoId) {
  try {
    console.log('Processing Invidious data in the user-specified format');
    
    // オリジナルコードに戻す（ユーザーの要求通り）
    // def get_data(videoid):
    // global logs
    // t = json.loads(apirequest(r"api/v1/videos/"+ urllib.parse.quote(videoid)))
    // return [{"id":i["videoId"],"title":i["title"],"authorId":i["authorId"],"author":i["author"]} for i in t["recommendedVideos"]],list(reversed([i["url"] for i in t["formatStreams"]]))[:2],t["descriptionHtml"].replace("\n","<br>"),t["title"],t["authorId"],t["author"],t["authorThumbnails"][-1]["url"]
    
    // recommendedVideosが存在することを確認
    if (!apiResponse.recommendedVideos) {
      console.error('No recommendedVideos found in API response');
      apiResponse.recommendedVideos = [];
    }
    
    // formatStreamsが存在することを確認
    if (!apiResponse.formatStreams) {
      console.error('No formatStreams found in API response');
      apiResponse.formatStreams = [];
    }
    
    // 1. 関連動画を指定フォーマットに加工
    const recommendedVideos = apiResponse.recommendedVideos.map(video => ({
      id: video.videoId,
      title: video.title,
      authorId: video.authorId,
      author: video.author
    }));
    
    // 2. ストリームURLを取得（最大2つのURLを逆順で）
    const streamUrls = apiResponse.formatStreams.map(stream => stream.url).reverse().slice(0, 2);
    
    // 3. 説明文の処理（改行を<br>に変換）
    const description = apiResponse.descriptionHtml ? apiResponse.descriptionHtml.replace(/\n/g, '<br>') : '';
    
    // 4. 動画タイトル
    const videoTitle = apiResponse.title || 'Untitled Video';
    
    // 5. チャンネルID
    const channelId = apiResponse.authorId || '';
    
    // 6. チャンネル名
    const channelName = apiResponse.author || 'Unknown Channel';
    
    // 7. チャンネルサムネイル
    let channelImage = '';
    if (apiResponse.authorThumbnails && apiResponse.authorThumbnails.length > 0) {
      channelImage = apiResponse.authorThumbnails[apiResponse.authorThumbnails.length - 1].url;
    }
    
    // クライアント側で使用する形式に変換
    return {
      videoId: videoId,
      streamUrls: streamUrls.map((url, index) => ({
        url: url,
        resolution: index === 0 ? 'high' : 'medium',
        type: 'video/mp4',
        hasAudio: true,
        hasVideo: true
      })),
      stream_url: streamUrls[0] || '',
      highstreamUrl: streamUrls[1] || streamUrls[0] || '',
      channelId: channelId,
      channelName: channelName,
      channelImage: channelImage,
      videoTitle: videoTitle,
      videoDes: description,
      recommendedVideosProcessed: recommendedVideos,
      viewCount: apiResponse.viewCount || '0',
      likeCount: apiResponse.likeCount || '0',
      publishedAt: apiResponse.publishedAt || ''
    };
  } catch (error) {
    console.error('Error processing Invidious data:', error);
    // エラーが発生しても元のデータを返す
    return apiResponse;
  }
}

async function ggvideo(videoId) {
  const startTime = Date.now();
  const instanceErrors = new Set();
  
  // APIリストが最新であることを確認
  if (Math.floor(Math.random() * 20) === 0) {
    await getapisgit();
  }
  
  if(!apis || apis.length === 0){
    await getapisgit();
  }
  
  if (!apis || !Array.isArray(apis) || apis.length === 0) {
    // Fallback to a default Invidious instance if we can't fetch the list
    try {
      // ユーザーの要求通り、標準のInvidious APIエンドポイントパスを使用
      const apiUrl = `https://vid.puffyan.us${INVIDIOUS_VIDEO_PATH}${videoId}`;
      console.log(`Using fallback URL: ${apiUrl}`);
      
      const response = await axios.get(apiUrl, { 
        timeout: MAX_API_WAIT_TIME,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
      });
      
      if (response.data) {
        // 新しい形式でデータを処理
        return processInvidiousData(response.data, videoId);
      } else {
        throw new Error("Empty response from fallback URL");
      }
    } catch (error) {
      console.error(`Error with fallback URL: ${error.message}`);
      throw error;
    }
  }
  
  // APIインスタンスをシャッフルして使用（負荷分散のため）
  const shuffledApis = [...apis].sort(() => Math.random() - 0.5);
  
  for (const instance of shuffledApis) {
    try {
      // ユーザーの要求通り、標準のInvidious APIエンドポイントパスを使用
      const apiUrl = `${instance}${INVIDIOUS_VIDEO_PATH}${videoId}`;
      console.log(`Attempting Invidious URL: ${apiUrl}`);
      
      const response = await axios.get(apiUrl, { 
        timeout: MAX_API_WAIT_TIME,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
      });
      
      if (response.data) {
        console.log(`Successfully retrieved video from Invidious API: ${instance}`);
        // 新しい形式でデータを処理
        return processInvidiousData(response.data, videoId);
      } else {
        console.error(`Empty response from: ${instance}`);
      }
    } catch (error) {
      console.error(`Error with Invidious instance: ${instance} - ${error.message}`);
      instanceErrors.add(instance);
    }

    if (Date.now() - startTime >= MAX_TIME) {
      throw new Error("Connection timeout during Invidious API requests");
    }
  }
  throw new Error(`Could not retrieve video from any Invidious API instance. Errors: ${Array.from(instanceErrors).join(', ')}`);
}

// 複数サーバー対応とyt-dlpを使用するためのモジュールをインポート
import { getYouTube as getMultiServerYouTube } from './wakame.js';
import { getVideoInfo as getYtDlpInfo } from './ytdlp.js';

async function getYouTube(videoId, options = {}) {
  try {
    // 指定されたサーバーやモードがある場合はそれを使用
    const { serverUrl, preferredServer, mode } = options;
    
    // 1. 特定のサーバーが指定されている場合、そのサーバーから先に取得を試みる
    if (serverUrl && mode === 'invidious') {
      try {
        console.log(`Fetching from specified Invidious instance: ${serverUrl}`);
        const apiUrl = `${serverUrl}${INVIDIOUS_VIDEO_PATH}${videoId}`;
        
        const response = await axios.get(apiUrl, {
          timeout: 10000,
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
          }
        });
        
        if (response.data) {
          console.log(`Successfully received data from specified Invidious instance for ${videoId}`);
          return processInvidiousData(response.data, videoId);
        }
      } catch (serverError) {
        console.error(`Error fetching from specified Invidious instance: ${serverError.message}, falling back to other methods`);
      }
    }
    
    // 2. モードに応じて適切なAPIを使用
    if (mode === 'wakame' || preferredServer === 'wakame') {
      try {
        console.log(`Trying Wakame API for video: ${videoId}`);
        const wakameData = await getMultiServerYouTube(videoId);
        return wakameData;
      } catch (wakameError) {
        console.error(`Wakame API fetch failed: ${wakameError.message}, falling back to Invidious`);
      }
    }
    
    // 3. デフォルトはInvidious APIを使用
    console.log(`Fetching video with ID: ${videoId} using Invidious API`);
    return await ggvideo(videoId);
  } catch (error) {
    console.error(`Error in getYouTube for video ${videoId}:`, error);
    throw error;
  }
}

/**
 * 利用可能なサーバーリストを返す
 * @returns {Array} サーバー情報の配列
 */
function getServerList() {
  const servers = [
    { id: 'auto', name: '自動選択 (Invidious→Wakame)', url: null },
    { id: 'wakame', name: 'Wakame API (複数サーバー)', url: null }
  ];
  
  // 利用可能なInvidiousサーバーも追加
  if (apis && apis.length > 0) {
    apis.forEach((api, index) => {
      servers.push({
        id: `invidious-${index}`,
        name: `Invidious: ${new URL(api).hostname}`,
        url: api
      });
    });
  }
  
  return servers;
}

export { getYouTube, getApiInstances, getServerList };