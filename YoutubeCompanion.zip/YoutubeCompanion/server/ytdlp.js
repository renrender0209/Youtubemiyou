// 新しいyt-dlpサービスをインポート
import { getVideoInfo as getYtDlpServiceInfo } from './ytdlp-service.js';

/**
 * yt-dlpを使用して動画の詳細情報を取得する（新しいサービスを使用）
 * @param {string} videoId YouTube動画ID
 * @param {boolean} fetchVideoStream 動画ストリームを取得するかどうか
 * @returns {Object} 動画情報
 */
export async function getVideoInfo(videoId, fetchVideoStream = false) {
  try {
    console.log(`Getting video metadata for ${videoId} using yt-dlp`);
    
    // 新しいyt-dlpサービスを使用
    const videoInfo = await getYtDlpServiceInfo(videoId, fetchVideoStream);
    
    console.log(`Successfully retrieved video info for ${videoId} using yt-dlp`);
    if (videoInfo.comments) {
      console.log(`Retrieved ${videoInfo.comments.length} comments for video ${videoId}`);
    }
    
    return videoInfo;
  } catch (error) {
    console.error(`Error using yt-dlp for video ${videoId}:`, error);
    throw new Error(`Failed to get video information using yt-dlp: ${error.message}`);
  }
}