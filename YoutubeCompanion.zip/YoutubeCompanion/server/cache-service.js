/**
 * シンプルなインメモリキャッシュサービス
 * 動画情報をキャッシュして、yt-dlpの呼び出し回数を減らします
 */

// キャッシュデータを保持するオブジェクト
const cache = new Map();

// キャッシュの有効期間 (30分)
const CACHE_TTL = 30 * 60 * 1000;

/**
 * キャッシュからデータを取得する
 * @param {string} videoId - YouTube動画ID
 * @returns {Object|null} - キャッシュされたデータまたはnull
 */
export function getFromCache(videoId) {
  // キャッシュにデータがあるか確認
  if (cache.has(videoId)) {
    const cachedData = cache.get(videoId);
    
    // キャッシュが有効期限内かチェック
    const now = Date.now();
    const isExpired = now - cachedData.timestamp > CACHE_TTL;
    
    if (!isExpired) {
      console.log(`Cache hit for video ${videoId} (cached ${Math.floor((now - cachedData.timestamp) / 1000)} seconds ago)`);
      return cachedData;
    } else {
      console.log(`Cache expired for video ${videoId} (cached ${Math.floor((now - cachedData.timestamp) / 1000)} seconds ago)`);
      // 期限切れのエントリを削除
      cache.delete(videoId);
      return null;
    }
  }
  
  console.log(`Cache miss for video ${videoId}`);
  return null;
}

/**
 * データをキャッシュに保存する
 * @param {string} videoId - YouTube動画ID
 * @param {Array} formats - 動画フォーマット情報
 * @param {Object} videoDetails - 動画詳細情報
 */
export function saveToCache(videoId, formats, videoDetails) {
  // タイムスタンプと一緒にデータを保存
  const timestamp = Date.now();
  cache.set(videoId, {
    formats,
    videoDetails,
    timestamp
  });
  
  console.log(`Cached data for video ${videoId} (cache size: ${cache.size} entries)`);
  
  // キャッシュサイズが大きくなり過ぎたら古いエントリを削除
  pruneCache();
}

/**
 * キャッシュをクリーンアップする
 * 古いエントリと期限切れのエントリを削除
 */
function pruneCache() {
  // キャッシュサイズの上限 (100エントリ)
  const MAX_CACHE_SIZE = 100;
  
  if (cache.size <= MAX_CACHE_SIZE) {
    return;
  }
  
  console.log(`Cache size (${cache.size}) exceeds limit, pruning old entries...`);
  
  const now = Date.now();
  const entries = Array.from(cache.entries());
  
  // タイムスタンプでソートして古いものから削除
  entries.sort((a, b) => a[1].timestamp - b[1].timestamp);
  
  // 古いエントリを削除
  const entriesToRemove = entries.slice(0, entries.length - MAX_CACHE_SIZE);
  for (const [key] of entriesToRemove) {
    cache.delete(key);
  }
  
  // 期限切れのエントリも削除
  for (const [key, value] of cache.entries()) {
    if (now - value.timestamp > CACHE_TTL) {
      cache.delete(key);
    }
  }
  
  console.log(`Pruned cache to ${cache.size} entries`);
}

/**
 * キャッシュをクリアする
 */
export function clearCache() {
  const size = cache.size;
  cache.clear();
  console.log(`Cleared cache (${size} entries removed)`);
}