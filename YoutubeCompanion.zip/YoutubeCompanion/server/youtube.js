import axios from 'axios';
import { getYouTube } from './youtube-api.js';

// YouTube API proxy functions
async function getVideoById(videoId, options = {}) {
  try {
    const videoData = await getYouTube(videoId, options);
    return videoData;
  } catch (error) {
    console.error(`Error fetching video ${videoId}:`, error);
    throw error;
  }
}

// Get the list of API instances from youtube-api.js
import { getApiInstances } from './youtube-api.js';

async function tryApiRequest(apiPath, attempts = 3) {
  const instances = getApiInstances();
  let lastError = null;
  
  // Try each instance until we find one that works
  for (const instance of instances) {
    try {
      const response = await axios.get(`${instance}${apiPath}`, { timeout: 5000 });
      if (response.data) {
        return response.data;
      }
    } catch (error) {
      console.error(`Error with instance ${instance} for ${apiPath}:`, error.message);
      lastError = error;
      // Continue to next instance
    }
  }
  
  if (lastError) throw lastError;
  throw new Error(`Failed to get data from any instance for ${apiPath}`);
}

async function searchVideos(query) {
  try {
    // Use multiple instances for search
    const apiPath = `/api/v1/search?q=${encodeURIComponent(query)}&type=video`;
    const searchResults = await tryApiRequest(apiPath);

    // Return only first 10 results to avoid too many API calls
    const limitedResults = searchResults.slice(0, 10);

    // Format the search results to match our expected format
    const videos = limitedResults.map(item => ({
      videoId: item.videoId,
      videoTitle: item.title,
      channelName: item.author,
      channelId: item.authorId,
      channelImage: item.authorThumbnails?.[0]?.url || '',
      viewCount: item.viewCount || '0',
      publishedAt: item.publishedText || '',
      thumbnail: item.videoThumbnails?.[0]?.url || '',
      duration: formatDuration(item.lengthSeconds || 0)
    }));

    return { videos };
  } catch (error) {
    console.error(`Error searching for videos with query "${query}":`, error);
    throw error;
  }
}

async function getTrendingVideos(region = 'JP', limit = 20) {
  try {
    // 日本のトレンド動画を取得 (デフォルト)
    const apiPath = `/api/v1/trending?region=${region}`;
    console.log(`Fetching trending videos from ${apiPath}`);
    const trendingVideos = await tryApiRequest(apiPath);

    // 指定された件数だけ結果を返す
    const limitedResults = trendingVideos.slice(0, limit);

    // 動画情報を標準フォーマットに変換
    const videos = limitedResults.map(item => ({
      videoId: item.videoId,
      videoTitle: item.title,
      channelName: item.author,
      channelId: item.authorId,
      channelImage: item.authorThumbnails?.[0]?.url || '',
      viewCount: item.viewCount || '0',
      publishedAt: item.publishedText || '',
      thumbnail: item.videoThumbnails?.[0]?.url || '',
      duration: formatDuration(item.lengthSeconds || 0)
    }));

    return { videos };
  } catch (error) {
    console.error(`Error fetching trending videos for region ${region}:`, error);
    throw error;
  }
}

async function getRelatedVideos(videoId) {
  try {
    // Use multiple instances for related videos
    const apiPath = `/api/v1/videos/${videoId}`;
    const videoData = await tryApiRequest(apiPath);
    const relatedVideos = videoData.recommendedVideos || [];

    // Format the results to match our expected format
    const videos = relatedVideos.map(item => ({
      videoId: item.videoId,
      videoTitle: item.title,
      channelName: item.author,
      channelId: item.authorId,
      viewCount: item.viewCount || '0',
      publishedAt: item.publishedText || '',
      thumbnail: item.videoThumbnails?.[0]?.url || '',
      duration: formatDuration(item.lengthSeconds || 0)
    }));

    return { videos };
  } catch (error) {
    console.error(`Error fetching related videos for ${videoId}:`, error);
    throw error;
  }
}

// Helper function to format duration from seconds to mm:ss or hh:mm:ss
function formatDuration(seconds) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = seconds % 60;

  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  } else {
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  }
}

export {
  getVideoById,
  searchVideos,
  getTrendingVideos,
  getRelatedVideos
};
