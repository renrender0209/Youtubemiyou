import { spawn } from 'child_process';
import { getFromCache, saveToCache } from './cache-service.js';
import path from 'path';
import * as fs from 'fs';

// yt-dlpバイナリのパス設定（環境に応じて異なるパスを使用）
// letを使用して後で変更可能にする
let YT_DLP_PATH = '/nix/store/mj7z8g8zfm3nd2ihymkk83czk9yz4xzd-python3.11-yt-dlp-2024.5.27/bin/yt-dlp';

// Render環境の場合は特別なパスを使用
if (process.env.RENDER === 'true') {
  // Renderでは.pythonlibsディレクトリ内に配置される
  YT_DLP_PATH = path.join('/opt/render/project/.pythonlibs/bin/yt-dlp');
} else if (process.env.YT_DLP_PATH) {
  // 環境変数が設定されている場合はそれを使用
  YT_DLP_PATH = process.env.YT_DLP_PATH;
}

console.log('Using YT_DLP_PATH:', YT_DLP_PATH);

// デプロイ環境に基づいたCookieディレクトリとファイルパスの設定
let COOKIES_DIR = '';

// Render環境では/tmpディレクトリに保存
if (process.env.RENDER === 'true') {
  COOKIES_DIR = path.join('/tmp', 'har_and_cookies');
  // ディレクトリがなければ作成
  if (!fs.existsSync(COOKIES_DIR)) {
    try {
      fs.mkdirSync(COOKIES_DIR, { recursive: true });
      console.log(`Created cookies directory for Render: ${COOKIES_DIR}`);
    } catch (err) {
      console.error(`Failed to create cookies directory for Render: ${err}`);
    }
  }
} else if (process.env.DEPLOY_ENV === 'render') {
  // 互換性のために古い変数も確認
  COOKIES_DIR = path.join('/tmp', 'har_and_cookies');
} else {
  // その他の環境ではプロジェクトディレクトリに保存
  COOKIES_DIR = path.join(process.cwd(), 'har_and_cookies');
}

const COOKIES_PATH = path.join(COOKIES_DIR, 'youtube_cookies.txt');

/**
 * Cookieファイルが存在するか確認
 */
function hasCookiesFile() {
  try {
    const exists = fs.existsSync(COOKIES_PATH);
    if (exists) {
      // ファイルサイズも確認（空でないか）
      const stats = fs.statSync(COOKIES_PATH);
      if (stats.size < 10) { // 最小サイズ
        console.warn('Cookie file exists but is too small (possibly empty or corrupted):', COOKIES_PATH);
        return false;
      }
      console.log(`Cookie file exists and valid: ${COOKIES_PATH} (${stats.size} bytes)`);
    } else {
      console.warn('Cookie file does not exist:', COOKIES_PATH);
    }
    return exists;
  } catch (error) {
    console.warn('Cookie file check failed:', error);
    return false;
  }
}

/**
 * Cookieファイルを保存する
 */
export function saveCookies(cookieContent) {
  try {
    if (!cookieContent || cookieContent.trim().length < 10) {
      console.error('Invalid cookie content: too short or empty');
      return false;
    }

    // クッキー形式を検証
    if (!cookieContent.includes('.youtube.com')) {
      console.warn('Warning: Cookie content does not contain .youtube.com domain, it may not be valid');
    }

    // har_and_cookiesディレクトリが存在することを確認
    const dir = path.dirname(COOKIES_PATH);
    if (!fs.existsSync(dir)) {
      console.log(`Creating cookies directory: ${dir}`);
      fs.mkdirSync(dir, { recursive: true });
    }
    
    // Cookieファイルを保存
    fs.writeFileSync(COOKIES_PATH, cookieContent);
    console.log(`Cookies saved to ${COOKIES_PATH} (${cookieContent.length} bytes)`);
    
    // 保存されていることを確認
    if (fs.existsSync(COOKIES_PATH)) {
      const stats = fs.statSync(COOKIES_PATH);
      console.log(`Verified cookie file saved: ${stats.size} bytes`);
      return true;
    } else {
      console.error('Cookie file was not saved properly');
      return false;
    }
  } catch (error) {
    console.error('Failed to save cookies:', error);
    return false;
  }
}

/**
 * yt-dlpを使用してYouTube動画情報を取得する
 */
export async function getVideoInfo(videoId, fetchVideoStream = true) {
  // まずキャッシュをチェック
  const cachedData = getFromCache(videoId);
  if (cachedData) {
    console.log(`Using cached data for video ${videoId}`);
    return {
      ...cachedData,
      fromCache: true
    };
  }

  console.log(`Fetching video info for ${videoId} using yt-dlp`);
  const url = `https://www.youtube.com/watch?v=${videoId}`;
  
  // 複数回リトライする
  const maxRetries = 3;
  let lastError = null;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      if (attempt > 1) {
        console.log(`Retry attempt ${attempt}/${maxRetries} for video ${videoId}`);
      }
      
      const rawInfo = await runYtDlp(url, fetchVideoStream);
      if (!rawInfo) {
        throw new Error('Failed to get video info from yt-dlp');
      }
      
      // パースして必要な情報を抽出
      const info = JSON.parse(rawInfo);
      
      // フォーマット情報を変換
      const streamUrls = convertFormats(info.formats || []);
      
      // ストリームURLの作成
      let stream_url = '';
      let highstreamUrl = '';
      let audioUrl = '';
      
      // 音声付きの動画フォーマットを優先して選択
      const audioVideoFormat = streamUrls.find(s => s.hasAudio && s.hasVideo);
      if (audioVideoFormat) {
        stream_url = audioVideoFormat.url;
      } else if (streamUrls.length > 0) {
        stream_url = streamUrls[0].url;
      }
      
      // 高画質URLの設定（できるだけ720p以上を選ぶ）
      const hdStream = streamUrls.find(s => {
        const resolution = s.resolution.replace('p', '');
        return s.hasAudio && s.hasVideo && parseInt(resolution) >= 720;
      });
      
      if (hdStream) {
        highstreamUrl = hdStream.url;
      } else if (stream_url) {
        highstreamUrl = stream_url;
      }
      
      // オーディオのみのURLを探す
      const audioOnlyStream = streamUrls.find(s => s.hasAudio && !s.hasVideo);
      if (audioOnlyStream) {
        audioUrl = audioOnlyStream.url;
      } else if (stream_url) {
        audioUrl = stream_url;
      }
      
      // サムネイル選択
      let thumbnailUrl = '';
      if (info.thumbnails && info.thumbnails.length > 0) {
        const highestQualityThumbnail = info.thumbnails.reduce((prev, current) => {
          return (prev.height > current.height) ? prev : current;
        });
        thumbnailUrl = highestQualityThumbnail.url;
      }
      
      // コメントの処理
      let comments = [];
      if (info.comments && Array.isArray(info.comments)) {
        console.log(`Retrieved ${info.comments.length} comments for video ${videoId}`);
        comments = info.comments.map(comment => {
          return {
            id: comment.id || `comment-${Math.random().toString(36).substring(2, 15)}`,
            text: comment.text || '',
            author: comment.author || 'Unknown User',
            authorAvatar: comment.author_thumbnail || '',
            publishedAt: comment.timestamp ? new Date(comment.timestamp * 1000).toISOString() : '',
            likeCount: comment.like_count || 0,
            isPinned: !!comment.is_pinned,
            isAuthorChannelOwner: !!comment.is_author_channel_owner
          };
        }).slice(0, 50); // 最初の50件のコメントのみを取得
      } else {
        console.log(`No comments found for video ${videoId} or comments retrieval failed`);
      }
      
      // 結果を作成
      const result = {
        stream_url,
        highstreamUrl,
        audioUrl,
        videoId: info.id,
        channelId: info.channel_id || '',
        channelName: info.uploader || info.channel || 'Unknown Channel',
        channelImage: '', // yt-dlpでは取得しにくい
        videoTitle: info.title || 'Untitled Video',
        videoDes: info.description || '',
        videoViews: info.view_count ? info.view_count.toString() : '0',
        likeCount: info.like_count ? info.like_count.toString() : '0',
        publishedAt: info.upload_date ? formatUploadDate(info.upload_date) : '',
        thumbnail: thumbnailUrl,
        duration: info.duration ? formatDuration(info.duration) : '',
        streamUrls,
        comments,
        uploadDate: info.upload_date ? formatUploadDate(info.upload_date) : '',
        // 追加メタデータ
        categories: info.categories || [],
        tags: info.tags || []
      };
      
      // キャッシュに保存
      saveToCache(videoId, result, {});
      
      return result;
    } catch (error) {
      console.error(`Error fetching video info for ${videoId} (attempt ${attempt}/${maxRetries}):`, error);
      lastError = error;
      
      // リトライ前に少し待機 (徐々に増加するバックオフ)
      if (attempt < maxRetries) {
        const backoffMs = 1000 * Math.pow(2, attempt - 1); // 1秒, 2秒, 4秒...
        console.log(`Waiting ${backoffMs}ms before next retry...`);
        await new Promise(resolve => setTimeout(resolve, backoffMs));
      }
    }
  }
  
  // すべてのリトライが失敗した場合
  console.error(`All ${maxRetries} attempts failed for video ${videoId}`);
  
  // フォールバック: ダミーデータを返さず、最後のエラーをスローして上位層に伝播させる
  throw lastError || new Error(`Failed to fetch video info for ${videoId} after ${maxRetries} attempts`);
}

/**
 * yt-dlpコマンドを実行する
 */
async function runYtDlp(url, fetchVideoStream = true) {
  return new Promise((resolve, reject) => {
    // yt-dlpバイナリの存在を確認
    try {
      if (!fs.existsSync(YT_DLP_PATH)) {
        console.error(`yt-dlp binary not found at path: ${YT_DLP_PATH}`);
        // バイナリが見つからない場合のフォールバックパスを探す
        const alternativePaths = [
          // Render環境のパス
          '/opt/render/project/.pythonlibs/bin/yt-dlp',
          // グローバルインストール
          '/usr/bin/yt-dlp',
          '/usr/local/bin/yt-dlp',
          // Nixpkgs（Replit用）
          '/nix/store/bin/yt-dlp',
          // Replit環境
          '/home/runner/workspace/.pythonlibs/bin/yt-dlp',
          // 相対パス
          path.join(process.cwd(), 'bin', 'yt-dlp'),
          // Windows用
          path.join(process.cwd(), 'bin', 'yt-dlp.exe'),
          // システムパス
          'yt-dlp', // PATHに含まれていればこれで実行できる
        ];
        
        let found = false;
        for (const altPath of alternativePaths) {
          try {
            // 特別なケース: 'yt-dlp'だけの場合はシステムコマンドを使用
            if (altPath === 'yt-dlp') {
              // ESMでは直接requireを使えないので、システムコマンドとして使用
              YT_DLP_PATH = 'yt-dlp';
              console.log(`Using system command for yt-dlp`);
              found = true;
              break;
            }
            
            // 通常のパスチェック
            if (fs.existsSync(altPath)) {
              console.log(`Using alternative yt-dlp path: ${altPath}`);
              // YT_DLP_PATHを動的に変更（letを使用しているので問題なし）
              YT_DLP_PATH = altPath;
              found = true;
              break;
            }
          } catch (pathErr) {
            console.warn(`Error checking alternative path ${altPath}: ${pathErr}`);
          }
        }
        
        if (!found) {
          console.warn('Could not find yt-dlp binary in any expected location');
          // 最後の手段：システムコマンドとしてyt-dlpを使用
          YT_DLP_PATH = 'yt-dlp';
          console.log('Falling back to system command: yt-dlp');
        }
      }
    } catch (err) {
      console.warn(`Error checking yt-dlp binary: ${err}`);
    }
    
    // 基本的な引数を設定
    const args = [
      '--dump-json',
      '--no-playlist',
      '--no-warnings',
      '--no-check-certificate',
      '--write-comments',
    ];
    
    // 動画ストリームを取得しない場合は、必要な情報のみに絞る
    if (!fetchVideoStream) {
      args.push('--skip-download');
      args.push('--no-check-formats');
    }
    
    // Cookieファイルがある場合は、それを使用
    if (hasCookiesFile()) {
      console.log(`Using cookies file: ${COOKIES_PATH}`);
      args.push('--cookies', COOKIES_PATH);
    } else {
      console.log('No cookies file found. YouTube might require authentication.');
    }
    
    // 最後にURLを追加
    args.push(url);
    
    // yt-dlpバージョンの確認は省略（ESM互換性問題のため）
    console.log(`Using yt-dlp at path: ${YT_DLP_PATH}`);
    
    console.log(`Running command: ${YT_DLP_PATH} ${args.join(' ')}`);
    
    let childProcess;
    try {
      childProcess = spawn(YT_DLP_PATH, args);
    } catch (spawnError) {
      console.error('Critical error spawning yt-dlp process:', spawnError);
      reject(spawnError);
      return;
    }
    
    if (!childProcess || !childProcess.stdout || !childProcess.stderr) {
      console.error('Failed to create valid child process');
      reject(new Error('Failed to create valid yt-dlp process'));
      return;
    }
    
    let stdout = '';
    let stderr = '';
    
    childProcess.stdout.on('data', (data) => {
      stdout += data.toString();
    });
    
    childProcess.stderr.on('data', (data) => {
      stderr += data.toString();
    });
    
    childProcess.on('close', (code) => {
      if (code === 0) {
        if (stdout.trim()) {
          resolve(stdout);
        } else {
          reject(new Error('yt-dlp returned empty output'));
        }
      } else {
        console.error(`yt-dlp process exited with code ${code}`);
        console.error(`stderr: ${stderr}`);
        reject(new Error(`yt-dlp process failed with exit code ${code}: ${stderr}`));
      }
    });
    
    childProcess.on('error', (err) => {
      console.error('yt-dlp process error:', err);
      reject(err);
    });
    
    // タイムアウト処理（2分）
    const timeout = setTimeout(() => {
      try {
        childProcess.kill();
      } catch (err) {
        console.warn('Error killing yt-dlp process on timeout:', err);
      }
      reject(new Error('yt-dlp process timed out after 120 seconds'));
    }, 120000);
    
    // クリーンアップ
    childProcess.on('exit', () => {
      clearTimeout(timeout);
    });
  });
}

/**
 * yt-dlpから返されるフォーマットを標準化されたフォーマットに変換
 */
function convertFormats(formats) {
  return formats.filter(format => {
    // バルク形式のURLは除外する
    return format.url && (format.vcodec !== 'none' || format.acodec !== 'none');
  }).map(format => {
    const hasAudio = format.acodec !== 'none';
    const hasVideo = format.vcodec !== 'none';
    
    // 解像度情報を取得
    let resolution = 'unknown';
    if (format.height) {
      resolution = `${format.height}p`;
    } else if (format.format_note) {
      // format_noteから解像度情報を抽出
      const formatNote = format.format_note.toLowerCase();
      if (formatNote.includes('low') || formatNote.includes('tiny')) {
        resolution = '144p';
      } else if (formatNote.includes('small')) {
        resolution = '240p';
      } else if (formatNote.includes('medium')) {
        resolution = '360p';
      } else if (formatNote.includes('large')) {
        resolution = '480p';
      } else if (formatNote.includes('hd720') || formatNote.includes('720')) {
        resolution = '720p';
      } else if (formatNote.includes('hd1080') || formatNote.includes('1080')) {
        resolution = '1080p';
      } else if (formatNote.includes('hd1440') || formatNote.includes('1440')) {
        resolution = '1440p';
      } else if (formatNote.includes('hd2160') || formatNote.includes('2160') || formatNote.includes('4k')) {
        resolution = '2160p';
      } else if (hasAudio && !hasVideo) {
        resolution = 'Audio';
      }
    } else if (hasAudio && !hasVideo) {
      resolution = 'Audio';
    }
    
    return {
      url: format.url,
      resolution: resolution,
      type: format.ext ? `video/${format.ext}` : 'video/mp4',
      qualityLabel: format.format_note || resolution,
      fps: format.fps || 30,
      container: format.ext || 'mp4',
      hasAudio,
      hasVideo,
      format_id: format.format_id
    };
  });
}

/**
 * 秒数を時:分:秒形式にフォーマット
 */
function formatDuration(seconds) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  
  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  } else {
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  }
}

/**
 * アップロード日付のフォーマット
 */
function formatUploadDate(uploadDate) {
  if (uploadDate && uploadDate.length === 8) {
    const year = uploadDate.substring(0, 4);
    const month = uploadDate.substring(4, 6);
    const day = uploadDate.substring(6, 8);
    return `${year}-${month}-${day}`;
  }
  return uploadDate;
}