import axios from 'axios';
import { getVideoInfo } from './ytdlp.js';

// 利用可能なサーバーのリスト
const serverUrls = [
  'https://watawata8.glitch.me',
  'https://watawata37.glitch.me',
  'https://watawatawata.glitch.me',
  'https://manawa.glitch.me',
  'https://wakeupe.glitch.me',
  'https://hortensia.glitch.me',
  'https://wata27.glitch.me',
  'https://wakameme.glitch.me',
  'https://siawaseok-wakame-server2.glitch.me'
];

// ユーザーエージェント設定
const user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36";

/**
 * 指定されたvideoIdに対する動画情報を複数のサーバーから取得を試みる
 * @param {string} videoId - 取得する動画のID
 * @param {string|null} preferredServer - 優先するサーバーのインデックスまたはURL（オプション）
 * @returns {object} 動画情報オブジェクト
 */
export async function getYouTube(videoId, preferredServer = null) {
  console.log(`Fetching video ${videoId} with multi-server strategy`);
  
  // エラーを格納する配列
  const errors = [];
  
  // サーバーリストをシャッフル
  const shuffledServers = shuffleArray([...serverUrls]);
  
  // 優先サーバーがある場合は先頭に移動
  if (preferredServer) {
    const serverUrl = isNaN(preferredServer) 
      ? preferredServer // URLが直接指定された場合
      : serverUrls[parseInt(preferredServer)]; // インデックスが指定された場合
    
    if (serverUrl) {
      const index = shuffledServers.indexOf(serverUrl);
      if (index > -1) {
        shuffledServers.splice(index, 1);
        shuffledServers.unshift(serverUrl);
      }
    }
  }
  
  // 1. まずyt-dlpを使って取得を試みる
  try {
    console.log('Attempting to fetch video using yt-dlp');
    const ytdlpData = await getVideoInfo(videoId);
    if (ytdlpData && ytdlpData.stream_url) {
      console.log('Successfully retrieved video using yt-dlp');
      return ytdlpData;
    }
  } catch (ytdlpError) {
    console.error(`yt-dlp fetch failed: ${ytdlpError.message}`);
    errors.push(`yt-dlp: ${ytdlpError.message}`);
  }
  
  // 2. 各サーバーで順に試行
  for (const serverUrl of shuffledServers) {
    try {
      console.log(`Attempting to fetch from server: ${serverUrl}`);
      const apiUrl = `${serverUrl}/api/${videoId}`;
      
      const response = await axios.get(apiUrl, {
        timeout: 10000, // 10秒タイムアウト
        headers: {
          'User-Agent': user_agent
        }
      });
      
      if (response.data && (response.data.stream_url || response.data.videoStreamUrl)) {
        // videoStreamUrlがある場合はstream_urlとして設定
        if (response.data.videoStreamUrl && !response.data.stream_url) {
          response.data.stream_url = response.data.videoStreamUrl;
        }
        
        // streamUrlsがない場合は作成
        if (!response.data.streamUrls || !Array.isArray(response.data.streamUrls) || response.data.streamUrls.length === 0) {
          response.data.streamUrls = [{
            url: response.data.stream_url,
            resolution: '720p', // デフォルト解像度
            type: 'video/mp4',
            hasAudio: true,
            hasVideo: true
          }];
        }
        
        console.log(`Successfully fetched video from ${serverUrl}`);
        return response.data;
      } else {
        console.log(`Server ${serverUrl} returned invalid data`);
        errors.push(`${serverUrl}: Invalid response data`);
      }
    } catch (error) {
      console.error(`Error fetching from ${serverUrl}: ${error.message}`);
      errors.push(`${serverUrl}: ${error.message}`);
    }
  }
  
  // すべてのサーバーで失敗した場合
  const errorMessage = `Failed to fetch video from all servers: ${errors.join('; ')}`;
  console.error(errorMessage);
  throw new Error(errorMessage);
}

/**
 * 配列をランダムにシャッフルする
 * @param {Array} array - シャッフルする配列
 * @returns {Array} シャッフルされた配列
 */
function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}