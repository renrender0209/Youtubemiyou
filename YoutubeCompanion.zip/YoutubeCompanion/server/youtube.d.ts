// Type definitions for the YouTube API module
export interface StreamUrl {
  url: string;
  resolution: string;
  type?: string;
  label?: string;
  qualityLabel?: string;
  fps?: number;
  container?: string;
  hasAudio?: boolean;
  hasVideo?: boolean;
}

export interface YouTubeVideo {
  videoId: string;
  videoTitle: string;
  channelName: string;
  channelId: string;
  channelImage: string;
  viewCount: string;
  likeCount: string;
  publishedAt?: string;
  thumbnail?: string;
  duration?: string;
  stream_url: string;
  highstreamUrl?: string;
  audioUrl?: string;
  videoDes: string;
  streamUrls: StreamUrl[];
}

export interface VideoSearchResults {
  videos: YouTubeVideo[];
}

export interface VideoOptions {
  mode?: string;
  serverUrl?: string;
  preferredServer?: string;
}

export function getVideoById(videoId: string, options?: VideoOptions): Promise<YouTubeVideo>;
export function searchVideos(query: string): Promise<VideoSearchResults>;
export function getTrendingVideos(region?: string, limit?: number): Promise<VideoSearchResults>;
export function getRelatedVideos(videoId: string): Promise<VideoSearchResults>;