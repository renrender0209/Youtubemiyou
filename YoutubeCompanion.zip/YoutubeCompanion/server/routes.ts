import express, { type Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import axios from 'axios';

// Import the YouTube API functions
import * as youtube from './youtube.js';
import { getServerList } from './youtube-api.js';

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  const apiRouter = express.Router();
  
  // GET video by ID
  apiRouter.get('/videos/:id', async (req: Request, res: Response) => {
    try {
      const videoId = req.params.id;
      console.log(`Fetching video with ID: ${videoId}`);

      // リクエストパラメータからオプションを取得
      const options = {
        mode: req.query.mode as string || 'auto',
        serverUrl: req.query.server as string,
        preferredServer: req.query.preferred as string
      };

      const videoData = await youtube.getVideoById(videoId, options);
      
      // ストリームURLをログ出力（セキュリティのため一部を隠す）
      if (videoData.stream_url) {
        const url = new URL(videoData.stream_url);
        console.log(`Main stream URL domain: ${url.hostname}`);
      }
      
      if (videoData.streamUrls && videoData.streamUrls.length > 0) {
        console.log(`Number of available streams: ${videoData.streamUrls.length}`);
        videoData.streamUrls.forEach((stream, index) => {
          try {
            const url = new URL(stream.url);
            console.log(`Stream ${index+1}: ${stream.resolution}, hasAudio: ${stream.hasAudio}, domain: ${url.hostname}`);
          } catch (e) {
            console.log(`Stream ${index+1}: Invalid URL`);
          }
        });
      }
      
      res.json(videoData);
    } catch (error) {
      console.error('Error fetching video:', error);
      res.status(500).json({ message: 'Failed to fetch video data' });
    }
  });
  
  // サーバーリストを取得するAPIエンドポイント
  apiRouter.get('/servers', (_req: Request, res: Response) => {
    // 現在登録されているすべてのサーバーリストを取得
    const servers = getServerList();
    
    // Wakameサーバーも追加
    const wakameServers = [
      { id: 'watawata8', name: 'Wakame: Watawata 8', url: 'https://watawata8.glitch.me' },
      { id: 'watawata37', name: 'Wakame: Watawata 37', url: 'https://watawata37.glitch.me' },
      { id: 'watawatawata', name: 'Wakame: Watawatawata', url: 'https://watawatawata.glitch.me' },
      { id: 'manawa', name: 'Wakame: Manawa', url: 'https://manawa.glitch.me' },
      { id: 'wakeupe', name: 'Wakame: Wakeupe', url: 'https://wakeupe.glitch.me' },
      { id: 'hortensia', name: 'Wakame: Hortensia', url: 'https://hortensia.glitch.me' },
      { id: 'wata27', name: 'Wakame: Wata 27', url: 'https://wata27.glitch.me' },
      { id: 'wakameme', name: 'Wakame: Wakameme', url: 'https://wakameme.glitch.me' },
      { id: 'wakame-server2', name: 'Wakame: Server 2', url: 'https://siawaseok-wakame-server2.glitch.me' }
    ];
    
    // 両方のリストを統合
    const allServers = [...servers, ...wakameServers];
    
    res.json({ servers: allServers });
  });

  // GET search videos
  apiRouter.get('/search', async (req: Request, res: Response) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: 'Query parameter is required' });
      }
      
      const searchResults = await youtube.searchVideos(query);
      res.json(searchResults);
    } catch (error) {
      console.error('Error searching videos:', error);
      res.status(500).json({ message: 'Failed to search for videos' });
    }
  });

  // GET trending videos
  apiRouter.get('/trending', async (req: Request, res: Response) => {
    try {
      // リージョンパラメータを取得 (デフォルトはJP - 日本)
      const region = (req.query.region as string) || 'JP';
      // 取得する件数 (デフォルトは20件)
      const limit = parseInt(req.query.limit as string) || 20;
      
      console.log(`Fetching trending videos for region: ${region}, limit: ${limit}`);
      
      const trendingVideos = await youtube.getTrendingVideos(region, limit);
      res.json(trendingVideos);
    } catch (error) {
      console.error('Error fetching trending videos:', error);
      res.status(500).json({ message: 'Failed to fetch trending videos' });
    }
  });

  // GET related videos
  apiRouter.get('/related/:id', async (req: Request, res: Response) => {
    try {
      const videoId = req.params.id;
      const relatedVideos = await youtube.getRelatedVideos(videoId);
      res.json(relatedVideos);
    } catch (error) {
      console.error('Error fetching related videos:', error);
      res.status(500).json({ message: 'Failed to fetch related videos' });
    }
  });

  // プロキシルート - YouTubeのストリームURLを中継する
  apiRouter.get('/proxy/video', async (req: Request, res: Response, next: NextFunction) => {
    try {
      const videoUrl = req.query.url as string;
      
      if (!videoUrl) {
        return res.status(400).json({ message: 'URL parameter is required' });
      }
      
      console.log(`Proxying video stream request for: ${new URL(videoUrl).hostname}`);
      
      // ビデオストリームを取得してそのまま転送
      const response = await axios({
        method: 'get',
        url: videoUrl,
        responseType: 'stream',
        timeout: 30000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
      });
      
      // レスポンスヘッダーをコピー
      Object.keys(response.headers).forEach(key => {
        res.setHeader(key, response.headers[key]);
      });
      
      // クライアントブラウザでのクロスオリジン問題を解決するためのヘッダー
      res.setHeader('Access-Control-Allow-Origin', '*');
      
      // ステータスコードを設定
      res.status(response.status);
      
      // ストリームをパイプして送信
      response.data.pipe(res);
    } catch (error) {
      console.error('Error proxying video:', error);
      next(error);
    }
  });

  // Mount the API router at /api
  app.use('/api', apiRouter);

  const httpServer = createServer(app);

  return httpServer;
}
