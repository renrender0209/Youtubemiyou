# YouTube Viewer Application (Wakame API)

日本向けYouTube視聴アプリケーション。Invidious APIとWakame APIを活用して、日本のトレンド動画を表示し、シームレスな視聴体験を提供します。

## 機能

- 日本のYouTubeトレンド動画の表示
- 動画検索機能
- 関連動画の表示
- 複数のAPI（InvidiousとWakame）からの動画取得
- 日本語表記の再生回数と日付表示
- サーバー選択によるパフォーマンス最適化

## Render.comへのデプロイ

このプロジェクトはRender.comにデプロイできるように設定されています。

### デプロイ手順

1. Renderアカウントを作成し、ログインします
2. ダッシュボードから「New」→「Blueprint」を選択します
3. このリポジトリをGitHubからコネクトします
4. render.yamlファイルが自動的に検出され、サービス設定が適用されます
5. デプロイボタンをクリックして、デプロイを開始します

## 技術スタック

- フロントエンド: React、TypeScript、TailwindCSS、Shadcn UI
- バックエンド: Node.js、Express
- API統合: Invidious API、Wakame API
- ビルドツール: Vite、ESBuild