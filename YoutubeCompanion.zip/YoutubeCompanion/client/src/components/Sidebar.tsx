import { Link, useLocation } from "wouter";

export default function Sidebar() {
  const [location] = useLocation();
  
  const isActive = (path: string) => location === path;

  return (
    <aside className="md:w-64 lg:w-72 md:pr-4 hidden md:block">
      <div className="sticky top-20 overflow-y-auto h-[calc(100vh-5rem)] pb-20">
        <nav className="py-4">
          <ul>
            <li className="mb-1">
              <Link href="/">
                <a className={`flex items-center px-4 py-2 rounded-lg hover:bg-gray-100 ${isActive('/') ? 'bg-gray-100' : ''}`}>
                  <i className="fas fa-home w-6"></i>
                  <span>ホーム</span>
                </a>
              </Link>
            </li>
            {/* Trendingは非表示
            <li className="mb-1">
              <a href="#" className="flex items-center px-4 py-2 rounded-lg hover:bg-gray-100">
                <i className="fas fa-fire w-6"></i>
                <span>トレンド</span>
              </a>
            </li>
            */}
            {/* 履歴も非表示
            <li className="mb-1">
              <a href="#" className="flex items-center px-4 py-2 rounded-lg hover:bg-gray-100">
                <i className="fas fa-history w-6"></i>
                <span>履歴</span>
              </a>
            </li>
            */}
          </ul>
          
          <div className="border-t border-divider my-4"></div>
          
          {/* ライブラリセクションも非表示
          <h3 className="px-4 text-sm font-semibold uppercase text-text-secondary mb-2">ライブラリ</h3>
          <ul>
            <li className="mb-1">
              <a href="#" className="flex items-center px-4 py-2 rounded-lg hover:bg-gray-100">
                <i className="fas fa-clock w-6"></i>
                <span>後で見る</span>
              </a>
            </li>
            <li className="mb-1">
              <a href="#" className="flex items-center px-4 py-2 rounded-lg hover:bg-gray-100">
                <i className="fas fa-thumbs-up w-6"></i>
                <span>高く評価した動画</span>
              </a>
            </li>
            <li className="mb-1">
              <a href="#" className="flex items-center px-4 py-2 rounded-lg hover:bg-gray-100">
                <i className="fas fa-folder w-6"></i>
                <span>再生リスト</span>
              </a>
            </li>
          </ul>
          
          <div className="border-t border-divider my-4"></div>
          */}
          
          <h3 className="px-4 text-sm font-semibold uppercase text-text-secondary mb-2">情報</h3>
          <ul>
            <li className="mb-1">
              <a href="#" className="flex items-center px-4 py-2 rounded-lg hover:bg-gray-100 text-sm">
                <i className="fas fa-info-circle w-6"></i>
                <span>このアプリは代替YouTube APIを使用しています</span>
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </aside>
  );
}
