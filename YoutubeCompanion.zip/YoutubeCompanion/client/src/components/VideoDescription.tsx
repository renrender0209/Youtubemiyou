import { useState } from "react";

interface VideoDescriptionProps {
  videoData: {
    videoDes: string;
  };
}

export default function VideoDescription({ videoData }: VideoDescriptionProps) {
  const [expanded, setExpanded] = useState(false);
  
  const toggleDescription = () => {
    setExpanded(!expanded);
  };

  // Convert URLs in description to clickable links
  const formatDescription = (text: string) => {
    if (!text) return "";
    
    // This regex matches URLs
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    
    return text.replace(urlRegex, (url) => {
      return `<a href="${url}" target="_blank" rel="noopener noreferrer" class="text-link-blue">${url}</a>`;
    });
  };

  return (
    <div className="p-4 bg-gray-50 rounded-lg mb-4">
      <div 
        className={`relative overflow-hidden ${expanded ? '' : 'max-h-[100px]'}`}
      >
        <div 
          className="whitespace-pre-line text-sm"
          dangerouslySetInnerHTML={{ __html: formatDescription(videoData.videoDes) }}
        />
        {!expanded && (
          <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-gray-50 to-transparent"></div>
        )}
      </div>
      <button 
        className="mt-2 text-sm font-medium"
        onClick={toggleDescription}
      >
        {expanded ? 'Show less' : 'Show more'}
      </button>
    </div>
  );
}
