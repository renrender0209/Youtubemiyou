import { useState } from "react";
import { Link } from "wouter";
import SearchBar from "./SearchBar";

export default function Header() {
  const [mobileSearchVisible, setMobileSearchVisible] = useState(false);
  const [mobileSidebarVisible, setMobileSidebarVisible] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm">
      <div className="container mx-auto px-4 py-2 flex justify-between items-center">
        <div className="flex items-center">
          <button 
            className="mr-4 lg:hidden" 
            onClick={() => setMobileSidebarVisible(!mobileSidebarVisible)}
            aria-label="Toggle sidebar"
          >
            <i className="fas fa-bars text-xl"></i>
          </button>
          <Link href="/" className="flex items-center">
            <i className="fab fa-youtube text-youtube-red text-3xl mr-1"></i>
            <h1 className="text-xl font-bold">YouTube Viewer</h1>
          </Link>
        </div>
        
        <div className="hidden md:flex items-center justify-center flex-1 max-w-3xl mx-4">
          <SearchBar />
        </div>
        
        <div className="flex items-center">
          <button 
            className="md:hidden mr-2"
            onClick={() => setMobileSearchVisible(!mobileSearchVisible)}
            aria-label="Toggle search"
          >
            <i className="fas fa-search text-xl"></i>
          </button>
          <button className="bg-link-blue text-white px-2 py-1 md:px-4 md:py-2 rounded-md text-sm">
            <i className="fas fa-sign-in-alt mr-1"></i>
            <span className="hidden md:inline">Sign In</span>
          </button>
        </div>
      </div>
      
      {/* Mobile Search Bar */}
      {mobileSearchVisible && (
        <div className="md:hidden px-4 py-2">
          <SearchBar isMobile={true} />
        </div>
      )}
    </header>
  );
}
