import { useState, useRef, useEffect } from "react";
import { Link, useRoute, useLocation } from "wouter";
import { getVideoById } from "../lib/youtube";
import { Button } from "./ui/button";
import { RefreshCcw, Share2, ThumbsUp, ThumbsDown, Download, MoreHorizontal } from "lucide-react";
import ServerSelector from "./ServerSelector";
import { formatViewCountJapanese } from "@/lib/utils";

interface StreamUrl {
  url: string;
  resolution: string;
  type?: string;
  label?: string;
  qualityLabel?: string;
  fps?: number;
  container?: string;
  hasAudio?: boolean;
  hasVideo?: boolean;
}

interface VideoPlayerProps {
  videoData: {
    stream_url: string;
    highstreamUrl?: string;
    audioUrl?: string;
    videoId: string;
    channelId: string;
    channelName: string;
    channelImage: string;
    videoTitle: string;
    videoDes: string;
    videoViews?: string;
    viewCount: string;
    likeCount: string;
    streamUrls: StreamUrl[];
  };
}

export default function VideoPlayer({ videoData }: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [currentStreamId, setCurrentStreamId] = useState<string>("");
  const [videoUrl, setVideoUrl] = useState<string>("");
  const [selectedStream, setSelectedStream] = useState<StreamUrl | null>(null);
  const [videoError, setVideoError] = useState<boolean>(false);
  const [fallbackMode, setFallbackMode] = useState<boolean>(false);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [, params] = useRoute("/watch/:id");
  
  // ストリームの一意なIDを生成
  const getStreamId = (stream: StreamUrl): string => {
    return `${stream.resolution}-${stream.hasAudio ? 'audio' : 'noaudio'}-${stream.fps || 30}`;
  };

  // 最初にデフォルトのビデオソースを設定
  useEffect(() => {
    console.log("Video data received:", videoData);
    
    // ビデオデータのURLをログに出力
    if (videoData.stream_url) {
      try {
        const url = new URL(videoData.stream_url);
        console.log(`Main stream URL host: ${url.hostname}, protocol: ${url.protocol}`);
      } catch (e) {
        console.error("Invalid stream URL:", e);
      }
    }
    
    // まずはじめに、最も信頼性の高いストリームURLを使用
    // これはAPIから直接返された主要なストリームURL
    if (videoData.stream_url) {
      console.log("Using primary stream URL with googlevideo.com domain");
      setVideoUrl(videoData.stream_url);
      setFallbackMode(true);
      setSelectedStream(null);
      setCurrentStreamId("default");
      return;
    }
    
    // stream_urlがない場合は、利用可能なストリームから選択
    if (videoData.streamUrls?.length) {
      setupBestStreamFromOptions();
    }
  }, [videoData]);
  
  // 利用可能なストリームから最適なものを選択
  const setupBestStreamFromOptions = () => {
    if (!videoData?.streamUrls?.length) return;
    
    console.log("Setting up best stream from options. Available streams:", videoData.streamUrls.length);
    
    // 音声付きのストリームを優先的に選択
    const audioStreams = videoData.streamUrls.filter(s => s.hasAudio === true);
    
    let bestStream = null;
    
    // 音声付きのストリームがある場合
    if (audioStreams.length > 0) {
      console.log(`Found ${audioStreams.length} streams with audio`);
      
      // 中画質（480p）を優先
      bestStream = audioStreams.find(s => s.resolution === '480p');
      
      // なければ最初のストリーム
      if (!bestStream) {
        bestStream = audioStreams[0];
      }
    } 
    // 音声なしの場合は最初のストリーム
    else if (videoData.streamUrls.length > 0) {
      bestStream = videoData.streamUrls[0];
    }
    
    if (bestStream) {
      console.log("Selected best stream:", bestStream.resolution, "hasAudio:", bestStream.hasAudio);
      setSelectedStream(bestStream);
      setVideoUrl(bestStream.url);
      setCurrentStreamId(getStreamId(bestStream));
    }
  };

  // 解像度変更時の処理
  const handleResolutionChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedResolutionId = e.target.value;
    
    // ユーザーがデフォルトに戻す場合
    if (selectedResolutionId === "default") {
      console.log("User selected default stream");
      setVideoUrl(videoData.stream_url);
      setFallbackMode(true);
      setSelectedStream(null);
      setCurrentStreamId("default");
      return;
    }
    
    setCurrentStreamId(selectedResolutionId);
    setFallbackMode(false);
    
    // ストリームを見つける
    const stream = videoData.streamUrls.find(s => getStreamId(s) === selectedResolutionId);
    
    if (stream) {
      console.log("Changing to stream:", stream.resolution, "hasAudio:", stream.hasAudio);
      setSelectedStream(stream);
      
      // 現在の再生状態を保存
      const currentTime = videoRef.current?.currentTime || 0;
      const isPlaying = videoRef.current ? !videoRef.current.paused : false;
      
      // 新しいURLを設定
      setVideoUrl(stream.url);
      
      // ビデオがロードされたら状態を復元
      if (videoRef.current) {
        videoRef.current.addEventListener('loadedmetadata', function onceLoaded() {
          if (videoRef.current) {
            videoRef.current.currentTime = currentTime;
            if (isPlaying) {
              videoRef.current.play().catch(e => console.error("Error playing video:", e));
            }
            videoRef.current.removeEventListener('loadedmetadata', onceLoaded);
          }
        });
      }
    }
  };
  
  // エラー処理
  const handleVideoError = () => {
    console.error("Video playback error occurred with URL:", videoUrl);
    setVideoError(true);
    
    // まだフォールバックモードでない場合は、デフォルトのストリームに切り替え
    if (!fallbackMode && videoData.stream_url) {
      console.log("Switching to fallback mode with URL:", videoData.stream_url);
      setVideoUrl(videoData.stream_url);
      setFallbackMode(true);
      setSelectedStream(null);
      setCurrentStreamId("default");
    }
  };

  // 再生回数を日本語表示するためのフォーマット
  const formatViewCount = (count: string | undefined) => {
    if (!count) return "0回再生";
    return formatViewCountJapanese(count);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm mb-4">
      <div className="relative pt-[56.25%]">
        {videoError ? (
          <div className="absolute top-0 left-0 w-full h-full flex items-center justify-center bg-gray-100">
            <div className="text-center p-4">
              <p className="text-xl font-bold mb-2">動画の読み込みエラー</p>
              <p className="mb-4">申し訳ありませんが、この動画を再生できませんでした。</p>
              <button 
                className="bg-youtube-red text-white px-4 py-2 rounded-lg"
                onClick={() => {
                  setVideoError(false);
                  if (videoData.stream_url) {
                    setVideoUrl(videoData.stream_url);
                    setFallbackMode(true);
                  }
                }}
              >
                再試行
              </button>
            </div>
          </div>
        ) : (
          <video 
            ref={videoRef}
            className="absolute top-0 left-0 w-full h-full" 
            controls
            autoPlay
            src={videoUrl}
            onError={handleVideoError}
            onLoadStart={() => console.log("Video load started:", videoUrl)}
            onLoadedData={() => console.log("Video loaded successfully:", videoUrl)}
          >
            {/* ブラウザがビデオタグをサポートしていない場合のメッセージ */}
            お使いのブラウザはビデオ再生をサポートしていません。
          </video>
        )}
      </div>
      
      <div className="p-4 border-b border-divider">
        <div className="flex flex-wrap justify-between items-center mb-4">
          <div className="mr-4">
            <h2 className="text-xl font-bold mb-1">{videoData.videoTitle}</h2>
            <div className="text-text-secondary text-sm">
              <span>{formatViewCount(videoData.videoViews || videoData.viewCount)}</span>
            </div>
          </div>
          
          {/* Resolution Selector */}
          {videoData.streamUrls && videoData.streamUrls.length > 0 && (
            <div className="flex items-center">
              <label htmlFor="resolutionSelect" className="mr-2 text-sm font-medium">画質:</label>
              <select 
                id="resolutionSelect" 
                className="bg-gray-100 border border-gray-300 text-text-primary rounded-md px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-youtube-red/50"
                value={currentStreamId}
                onChange={handleResolutionChange}
                style={{minWidth: '120px'}} // 選択ボックスを少し広くして見やすくする
              >
                {/* 音声付きのストリームを最初にソートして表示する */}
                {[...videoData.streamUrls]
                  .sort((a, b) => {
                    // 音声付きのストリームを優先
                    if (a.hasAudio && !b.hasAudio) return -1;
                    if (!a.hasAudio && b.hasAudio) return 1;
                    
                    // 次に解像度で比較
                    const heightA = parseInt(a.resolution.replace('p', ''));
                    const heightB = parseInt(b.resolution.replace('p', ''));
                    return heightB - heightA;
                  })
                  .map((stream) => {
                    const streamId = getStreamId(stream);
                    return (
                      <option key={streamId} value={streamId}>
                        {stream.hasAudio 
                          ? `${stream.resolution}${stream.fps && stream.fps > 30 ? ` ${stream.fps}fps` : ''} ✓` 
                          : `${stream.resolution}${stream.fps && stream.fps > 30 ? ` ${stream.fps}fps` : ''} (映像のみ)`}
                      </option>
                    );
                  })
                }
              </select>
            </div>
          )}
        </div>
        
        <div className="flex flex-wrap gap-2">
          <button className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-gray-100 hover:bg-gray-200">
            <ThumbsUp size={16} />
            <span>{videoData.likeCount || "0"}</span>
          </button>
          <button className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-gray-100 hover:bg-gray-200">
            <ThumbsDown size={16} />
          </button>
          <button className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-gray-100 hover:bg-gray-200">
            <Share2 size={16} />
            <span className="hidden sm:inline">共有</span>
          </button>
          <button className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-gray-100 hover:bg-gray-200">
            <Download size={16} />
            <span className="hidden sm:inline">ダウンロード</span>
          </button>
          <button className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-gray-100 hover:bg-gray-200 ml-auto">
            <MoreHorizontal size={16} />
          </button>
        </div>
      </div>
      
      {/* サーバーセレクターを配置 */}
      <div className="px-4 py-2 bg-gray-50 border-t border-divider">
        <ServerSelector videoId={videoData.videoId} />
      </div>
      
      <div className="p-4 flex flex-wrap items-center justify-between">
        <div className="flex items-center mb-2 sm:mb-0">
          <img 
            src={videoData.channelImage} 
            className="w-12 h-12 rounded-full mr-3"
            alt={videoData.channelName}
            onError={(e) => {
              // Fallback for failed channel image loads
              (e.target as HTMLImageElement).src = 'https://via.placeholder.com/48x48';
            }}
          />
          <div>
            <Link href={`/channel/${videoData.channelId}`}>
              <a className="font-semibold hover:text-link-blue">{videoData.channelName}</a>
            </Link>
          </div>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline"
            size="sm"
            className="flex items-center gap-1"
            disabled={isRefreshing}
            onClick={async () => {
              if (params?.id) {
                try {
                  setIsRefreshing(true);
                  
                  // 現在の再生位置を保存
                  const currentTime = videoRef.current?.currentTime || 0;
                  
                  // URLからクエリパラメータを取得
                  const urlSearchParams = new URLSearchParams(window.location.search);
                  const mode = urlSearchParams.get('mode');
                  const server = urlSearchParams.get('server');
                  const source = urlSearchParams.get('source');
                  
                  // オプションを構築
                  const options: Record<string, any> = {};
                  if (mode) options.mode = mode;
                  if (server) options.serverUrl = server;
                  if (source) options.preferredServer = source;
                  
                  // 新しいビデオデータを取得
                  const newVideoData = await getVideoById(params.id, options as any);
                  
                  // 新しいストリームURLが取得できた場合
                  if (newVideoData && newVideoData.stream_url) {
                    setVideoUrl(newVideoData.stream_url);
                    setVideoError(false);
                    
                    // ビデオがロードされた後、保存した時間に設定
                    if (videoRef.current) {
                      videoRef.current.addEventListener('loadedmetadata', function onceLoaded() {
                        if (videoRef.current) {
                          videoRef.current.currentTime = currentTime;
                          videoRef.current.removeEventListener('loadedmetadata', onceLoaded);
                        }
                      });
                    }
                  }
                } catch (error) {
                  console.error("動画再取得に失敗しました:", error);
                } finally {
                  setIsRefreshing(false);
                }
              }
            }}
          >
            <RefreshCcw size={16} className={isRefreshing ? "animate-spin" : ""} />
            <span>動画を再取得</span>
          </Button>
          <button className="bg-youtube-red text-white px-4 py-2 rounded-full font-medium hover:bg-red-700">
            チャンネル登録
          </button>
        </div>
      </div>
    </div>
  );
}
