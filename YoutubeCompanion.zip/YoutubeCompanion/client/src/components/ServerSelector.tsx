import { useState, useEffect } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";

interface Server {
  id: string;
  name: string;
  url: string | null;
}

interface ServerSelectorProps {
  videoId?: string;
  onServerChange?: (serverId: string) => void;
}

export default function ServerSelector({ videoId, onServerChange }: ServerSelectorProps) {
  const [servers, setServers] = useState<Server[]>([]);
  const [selectedServer, setSelectedServer] = useState<string>("auto");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [, setLocation] = useLocation();

  // サーバーリストを取得
  useEffect(() => {
    const fetchServers = async () => {
      try {
        setLoading(true);
        setError(null);
        const response = await apiRequest("GET", "/api/servers", undefined);
        const data = await response.json();
        if (data.servers) {
          setServers(data.servers);
        }
      } catch (err) {
        console.error("Failed to fetch servers:", err);
        setError("サーバーリストの取得に失敗しました");
      } finally {
        setLoading(false);
      }
    };

    fetchServers();
  }, []);

  // サーバー変更時の処理
  const handleServerChange = (value: string) => {
    setSelectedServer(value);
    
    // 親コンポーネントにサーバー変更を通知
    if (onServerChange) {
      onServerChange(value);
    }
    
    // 動画ID指定がある場合は、動画ページへ移動
    if (videoId) {
      // 選択したサーバーのURLを取得
      const server = servers.find(s => s.id === value);
      const serverParam = server?.url ? `&server=${encodeURIComponent(server.url)}` : "";
      const modeParam = !server?.url ? `&mode=${value}` : "";
      
      // 新しいURLへリダイレクト
      setLocation(`/watch/${videoId}?source=${value}${serverParam}${modeParam}`);
    }
  };

  return (
    <div className="mb-4">
      <div className="flex items-center space-x-2">
        <Label htmlFor="server-select" className="text-sm">動画取得サーバー:</Label>
        <Select value={selectedServer} onValueChange={handleServerChange} disabled={loading}>
          <SelectTrigger id="server-select" className="w-[200px]">
            <SelectValue placeholder="サーバーを選択" />
          </SelectTrigger>
          <SelectContent>
            {servers.map((server) => (
              <SelectItem key={server.id} value={server.id}>
                {server.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
      {loading && <p className="text-gray-500 text-xs mt-1">サーバーリストを読み込み中...</p>}
    </div>
  );
}