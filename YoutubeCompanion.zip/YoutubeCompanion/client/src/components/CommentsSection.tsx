import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Comment } from "../lib/youtube";

interface CommentsSectionProps {
  videoId: string;
  comments?: Comment[];
}

export default function CommentsSection({ videoId, comments: propComments }: CommentsSectionProps) {
  const [commentText, setCommentText] = useState("");
  const [comments, setComments] = useState<Comment[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // ビデオIDに基づいてコメントを取得（propCommentsがない場合）
  const { data: queryComments, isLoading: isLoadingComments } = useQuery<{ comments?: Comment[] }>({
    queryKey: [`/api/videos/${videoId}`],
    enabled: !propComments && !!videoId, // propCommentsがない場合のみクエリを実行
  });

  // propCommentsまたはクエリからのコメントを設定
  useEffect(() => {
    if (propComments && propComments.length > 0) {
      setComments(propComments);
    } else if (queryComments?.comments && Array.isArray(queryComments.comments)) {
      setComments(queryComments.comments);
    }
  }, [propComments, queryComments]);
  
  // 投稿日時を整形する関数
  const formatDate = (dateStr?: string) => {
    if (!dateStr) return '';
    
    try {
      const date = new Date(dateStr);
      
      // 日付が有効かどうかチェック
      if (isNaN(date.getTime())) {
        return dateStr; // 変換できない場合はそのまま返す
      }
      
      // 1年以上前
      const now = new Date();
      const diffYears = now.getFullYear() - date.getFullYear();
      
      if (diffYears > 0) {
        return `${diffYears} ${diffYears === 1 ? 'year' : 'years'} ago`;
      }
      
      // 1ヶ月以上前
      const diffMonths = now.getMonth() - date.getMonth() + (now.getFullYear() - date.getFullYear()) * 12;
      if (diffMonths > 0) {
        return `${diffMonths} ${diffMonths === 1 ? 'month' : 'months'} ago`;
      }
      
      // 1週間以上前
      const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
      if (diffDays >= 7) {
        const weeks = Math.floor(diffDays / 7);
        return `${weeks} ${weeks === 1 ? 'week' : 'weeks'} ago`;
      }
      
      // 1日以上前
      if (diffDays > 0) {
        return `${diffDays} ${diffDays === 1 ? 'day' : 'days'} ago`;
      }
      
      // 1時間以上前
      const diffHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
      if (diffHours > 0) {
        return `${diffHours} ${diffHours === 1 ? 'hour' : 'hours'} ago`;
      }
      
      // 1分以上前
      const diffMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
      if (diffMinutes > 0) {
        return `${diffMinutes} ${diffMinutes === 1 ? 'minute' : 'minutes'} ago`;
      }
      
      return 'Just now';
    } catch (error) {
      console.error('Date formatting error:', error);
      return dateStr;
    }
  };

  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (commentText.trim()) {
      // In a real app, this would send a request to post the comment
      console.log("Comment submitted:", commentText);
      setCommentText("");
      alert("Adding comments is not implemented in this viewer application, as it requires authentication");
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold">
          Comments {comments && comments.length > 0 ? `(${comments.length})` : ''}
        </h3>
        <button className="flex items-center text-sm text-text-secondary">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4h13M3 8h9m-9 4h6m4 0l4-4m0 0l4 4m-4-4v12" />
          </svg>
          Sort by
        </button>
      </div>
      
      <form onSubmit={handleSubmitComment} className="flex mb-6">
        <img 
          src="https://via.placeholder.com/32x32" 
          className="w-8 h-8 rounded-full mr-3" 
          alt="User" 
        />
        <div className="flex-1">
          <input 
            type="text" 
            placeholder="Add a comment..." 
            className="w-full px-3 py-2 border-b border-gray-300 focus:outline-none focus:border-blue-500"
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
          />
          {commentText && (
            <div className="flex justify-end mt-2">
              <button 
                type="button" 
                className="px-3 py-1 text-sm mr-2"
                onClick={() => setCommentText("")}
              >
                Cancel
              </button>
              <button 
                type="submit" 
                className="bg-blue-500 text-white px-3 py-1 rounded-full text-sm"
              >
                Comment
              </button>
            </div>
          )}
        </div>
      </form>
      
      {isLoading || isLoadingComments ? (
        <div className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      ) : comments && comments.length > 0 ? (
        <div className="space-y-6">
          {comments.map((comment) => (
            <div key={comment.id} className="flex">
              <img 
                src={comment.authorAvatar || "https://via.placeholder.com/40x40"} 
                className="w-10 h-10 rounded-full mr-3" 
                alt={comment.author} 
              />
              <div>
                <div className="flex items-center">
                  <span className="font-semibold text-sm mr-2">{comment.author}</span>
                  {comment.isAuthorChannelOwner && (
                    <span className="bg-gray-200 text-gray-700 text-xs px-1 rounded">Channel Owner</span>
                  )}
                  <span className="text-text-secondary text-xs ml-2">{formatDate(comment.publishedAt)}</span>
                </div>
                <p className="text-sm mt-1 whitespace-pre-line">{comment.text}</p>
                <div className="flex items-center mt-2 text-text-secondary text-sm">
                  <button className="flex items-center mr-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5" />
                    </svg>
                    {comment.likeCount || '0'}
                  </button>
                  <button className="mr-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 10v12m0 0l-3.5-3.5M7 22h.01M17 10V3.2a1.2 1.2 0 00-1.2-1.2h-.09c-.63 0-.97.36-1.12.85L12 10m0 0h7m-7 0l-1 5m8-5h-2.5" />
                    </svg>
                  </button>
                  <button>Reply</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-6 text-text-secondary">
          <p>No comments available for this video</p>
        </div>
      )}
    </div>
  );
}
