import { useQuery } from "@tanstack/react-query";
import VideoItem from "./VideoItem";

interface RelatedVideosProps {
  videoId: string;
}

export default function RelatedVideos({ videoId }: RelatedVideosProps) {
  const { data, isLoading, error } = useQuery({
    queryKey: [`/api/related/${videoId}`],
  });

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-4">
        <h3 className="font-semibold mb-4">Recommended videos</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="bg-gray-200 aspect-video rounded-lg mb-2"></div>
              <div className="flex">
                <div className="w-8 h-8 bg-gray-200 rounded-full mr-2"></div>
                <div className="flex-1">
                  <div className="h-4 bg-gray-200 rounded w-full mb-1"></div>
                  <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (error || !data || !data.videos || data.videos.length === 0) {
    return null; // Don't show anything if there's an error or no related videos
  }

  return (
    <div className="bg-white rounded-lg shadow-sm p-4">
      <h3 className="font-semibold mb-4">Recommended videos</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {data.videos.map((video: any) => (
          <VideoItem key={video.videoId} video={video} />
        ))}
      </div>
    </div>
  );
}
