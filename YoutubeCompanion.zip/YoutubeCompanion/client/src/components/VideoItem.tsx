import { Link } from "wouter";
import { formatViewCountJapanese, formatRelativeDateJapanese } from "@/lib/utils";

interface VideoItemProps {
  video: {
    videoId: string;
    videoTitle: string;
    channelName?: string;
    channelImage?: string;
    viewCount?: string;
    publishedAt?: string;
    thumbnail?: string;
    duration?: string;
  };
  layout?: "grid" | "horizontal";
}

export default function VideoItem({ video, layout = "grid" }: VideoItemProps) {
  // 日本語フォーマットの再生回数を取得
  const formattedViews = video.viewCount 
    ? formatViewCountJapanese(video.viewCount)
    : "";
  
  // 日本語フォーマットの相対日付
  const formattedTimeAgo = video.publishedAt
    ? formatRelativeDateJapanese(video.publishedAt)
    : "";

  // 表示用の時間情報を組み合わせ
  const timeAgo = video.publishedAt 
    ? `${formattedViews} • ${formattedTimeAgo}`
    : formattedViews;

  // Generate a fallback thumbnail URL using the video ID
  const thumbnailUrl = video.thumbnail || 
                       `https://i.ytimg.com/vi/${video.videoId}/mqdefault.jpg`;

  if (layout === "horizontal") {
    return (
      <Link href={`/watch/${video.videoId}`}>
        <a className="group flex flex-col sm:flex-row gap-4 hover:bg-gray-50 p-2 rounded-lg transition-colors">
          <div className="relative sm:w-64 rounded-lg overflow-hidden">
            <img 
              src={thumbnailUrl} 
              className="w-full aspect-video object-cover transition-transform group-hover:scale-105" 
              alt={video.videoTitle}
              loading="lazy"
              onError={(e) => {
                // Fallback for failed thumbnail loads
                (e.target as HTMLImageElement).src = 'https://via.placeholder.com/480x270?text=No+Thumbnail';
              }}
            />
            {video.duration && (
              <div className="absolute bottom-1 right-1 bg-black bg-opacity-80 text-white text-xs px-1 rounded">
                {video.duration}
              </div>
            )}
          </div>
          <div className="flex-1">
            <h4 className="font-medium text-base line-clamp-2 mb-1">{video.videoTitle}</h4>
            <p className="text-text-secondary text-xs">{video.channelName}</p>
            <p className="text-text-secondary text-xs">{timeAgo}</p>
          </div>
        </a>
      </Link>
    );
  }

  return (
    <Link href={`/watch/${video.videoId}`}>
      <a className="group cursor-pointer block">
        <div className="relative rounded-lg overflow-hidden mb-2">
          <img 
            src={thumbnailUrl} 
            className="w-full aspect-video object-cover transition-transform group-hover:scale-105" 
            alt={video.videoTitle}
            loading="lazy"
            onError={(e) => {
              // Fallback for failed thumbnail loads
              (e.target as HTMLImageElement).src = 'https://via.placeholder.com/480x270?text=No+Thumbnail';
            }}
          />
          {video.duration && (
            <div className="absolute bottom-1 right-1 bg-black bg-opacity-80 text-white text-xs px-1 rounded">
              {video.duration}
            </div>
          )}
        </div>
        <div className="flex">
          {video.channelImage && (
            <img 
              src={video.channelImage} 
              className="w-8 h-8 rounded-full mr-2" 
              alt={video.channelName || "Channel"}
              onError={(e) => {
                // Fallback for failed channel image loads
                (e.target as HTMLImageElement).src = 'https://via.placeholder.com/32x32';
              }}
            />
          )}
          <div>
            <h4 className="font-medium text-sm line-clamp-2">{video.videoTitle}</h4>
            {video.channelName && (
              <p className="text-text-secondary text-xs mt-1">{video.channelName}</p>
            )}
            <p className="text-text-secondary text-xs">{timeAgo}</p>
          </div>
        </div>
      </a>
    </Link>
  );
}
