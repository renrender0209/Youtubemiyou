import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";

interface SearchBarProps {
  isMobile?: boolean;
}

export default function SearchBar({ isMobile = false }: SearchBarProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [, navigate] = useLocation();
  const inputRef = useRef<HTMLInputElement>(null);
  const suggestionsRef = useRef<HTMLDivElement>(null);

  // Handle search submission
  const handleSearch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    
    if (searchTerm.trim()) {
      navigate(`/search/${encodeURIComponent(searchTerm.trim())}`);
      setShowSuggestions(false);
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setSearchTerm(suggestion);
    navigate(`/search/${encodeURIComponent(suggestion)}`);
    setShowSuggestions(false);
  };

  // Simple search suggestions (in a real app, this would call an API)
  useEffect(() => {
    if (searchTerm.length >= 2) {
      // This is just a mock implementation
      // In a real app, you would fetch suggestions from an API
      const demoSuggestions = [
        `${searchTerm} tutorial`,
        `${searchTerm} review`,
        `how to ${searchTerm}`,
        `best ${searchTerm}`,
        `${searchTerm} 2023`
      ];
      setSuggestions(demoSuggestions);
    } else {
      setSuggestions([]);
    }
  }, [searchTerm]);

  // Close suggestions when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        suggestionsRef.current && 
        !suggestionsRef.current.contains(event.target as Node) &&
        !inputRef.current?.contains(event.target as Node)
      ) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <form className="relative w-full" onSubmit={handleSearch}>
      <div className="flex items-center w-full">
        <input
          ref={inputRef}
          type="text"
          className="w-full px-4 py-2 border border-gray-300 rounded-l-full focus:outline-none focus:ring-2 focus:ring-youtube-red/50"
          placeholder="Search for videos"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          onFocus={() => {
            if (searchTerm.length >= 2) {
              setShowSuggestions(true);
            }
          }}
        />
        <button
          type="submit"
          className="bg-gray-100 px-5 py-2 border border-l-0 border-gray-300 rounded-r-full hover:bg-gray-200"
        >
          <i className="fas fa-search text-gray-600"></i>
        </button>
      </div>

      {showSuggestions && suggestions.length > 0 && (
        <div
          ref={suggestionsRef}
          className="absolute w-full bg-white border border-gray-200 rounded-b-lg shadow-lg z-10 mt-1"
        >
          {suggestions.map((suggestion, index) => (
            <div
              key={index}
              className="px-4 py-2 hover:bg-gray-100 cursor-pointer flex items-center"
              onClick={() => handleSuggestionClick(suggestion)}
            >
              <i className="fas fa-search text-gray-400 mr-2"></i>
              <span>{suggestion}</span>
            </div>
          ))}
        </div>
      )}
    </form>
  );
}
