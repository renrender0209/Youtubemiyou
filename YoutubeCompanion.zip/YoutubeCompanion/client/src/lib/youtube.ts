import { apiRequest } from "./queryClient";

export interface StreamUrl {
  url: string;
  resolution: string;
  type?: string;
  label?: string;
  qualityLabel?: string;
  fps?: number;
  container?: string;
  hasAudio?: boolean;
  hasVideo?: boolean;
}

export interface Comment {
  id: string;
  text: string;
  author: string;
  authorAvatar?: string;
  publishedAt?: string;
  likeCount?: number;
  isPinned?: boolean;
  isAuthorChannelOwner?: boolean;
}

export interface YouTubeVideo {
  videoId: string;
  videoTitle: string;
  channelName: string;
  channelId: string;
  channelImage: string;
  viewCount: string;
  likeCount: string;
  publishedAt?: string;
  uploadDate?: string;
  thumbnail?: string;
  duration?: string;
  stream_url: string;
  highstreamUrl?: string;
  audioUrl?: string;
  videoDes: string;
  streamUrls: StreamUrl[];
  comments?: Comment[];
  categories?: string[];
  tags?: string[];
  videoViews?: string; // ビデオの再生回数 (viewCountと同じ値を持つことができる)
}

export async function searchVideos(query: string): Promise<{ videos: YouTubeVideo[] }> {
  const response = await apiRequest("GET", `/api/search?q=${encodeURIComponent(query)}`, undefined);
  return await response.json();
}

export interface VideoOptions {
  mode?: string;
  serverUrl?: string;
  preferredServer?: string;
}

export async function getVideoById(id: string, options?: VideoOptions): Promise<YouTubeVideo> {
  // オプションからクエリパラメータを構築
  const queryParams = new URLSearchParams();
  if (options) {
    if (options.mode) queryParams.append('mode', options.mode);
    if (options.serverUrl) queryParams.append('server', options.serverUrl);
    if (options.preferredServer) queryParams.append('preferred', options.preferredServer);
  }
  
  // クエリパラメータがある場合はURLに追加
  const queryString = queryParams.toString() ? `?${queryParams.toString()}` : '';
  const response = await apiRequest("GET", `/api/videos/${id}${queryString}`, undefined);
  const videoData = await response.json();
  
  // オリジナルのストリームURLを保存
  const originalStreamUrl = videoData.stream_url;
  
  // URL変換ユーティリティ関数
  const convertToProxyUrl = (url: string) => {
    // URLをチェックして適切なプロキシを使用
    if (url.includes('googlevideo.com') || url.includes('youtube.com')) {
      // YouTubeドメインの場合、サーバープロキシを使用
      return `/api/proxy/video?url=${encodeURIComponent(url)}`;
    }
    // その他のURLの場合はそのまま返す
    return url;
  };
  
  // 元のURLがある場合、プロキシURLを作成して置き換える
  if (originalStreamUrl) {
    const proxyUrl = convertToProxyUrl(originalStreamUrl);
    console.log("Using video URL:", proxyUrl);
    videoData.stream_url = proxyUrl;
    
    // streamUrlsの各URLも同様に処理
    if (videoData.streamUrls && videoData.streamUrls.length > 0) {
      videoData.streamUrls = videoData.streamUrls.map((stream: StreamUrl) => {
        if (stream.url) {
          const streamProxyUrl = convertToProxyUrl(stream.url);
          return {
            ...stream,
            url: streamProxyUrl,
            originalUrl: stream.url // オリジナルURLを保存
          };
        }
        return stream;
      });
    }
  }
  
  return videoData;
}

export async function getTrending(): Promise<{ videos: YouTubeVideo[] }> {
  const response = await apiRequest("GET", "/api/trending", undefined);
  return await response.json();
}

export async function getRelatedVideos(videoId: string): Promise<{ videos: YouTubeVideo[] }> {
  const response = await apiRequest("GET", `/api/related/${videoId}`, undefined);
  return await response.json();
}
