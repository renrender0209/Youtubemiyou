import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * 数値を日本語の再生回数表示に変換します
 * @param viewCount 再生回数（文字列または数値）
 * @returns 日本語形式の再生回数（例: 123,456 → 12.3万回再生）
 */
export function formatViewCountJapanese(viewCount: string | number): string {
  if (!viewCount) return "0回再生";
  
  // 文字列の場合は数値に変換
  const count = typeof viewCount === 'string' 
    ? parseInt(viewCount.replace(/,/g, ''), 10) 
    : viewCount;
  
  if (isNaN(count)) return "0回再生";
  
  if (count >= 100000000) {
    // 1億以上
    return `${(count / 100000000).toFixed(1).replace(/\.0$/, '')}億回再生`;
  } else if (count >= 10000) {
    // 1万以上
    return `${(count / 10000).toFixed(1).replace(/\.0$/, '')}万回再生`;
  } else if (count >= 1000) {
    // 1000以上
    return `${(count / 1000).toFixed(1).replace(/\.0$/, '')}千回再生`;
  } else {
    // 1000未満
    return `${count}回再生`;
  }
}

/**
 * 日付文字列を相対時間の日本語表記に変換します
 * @param dateString 日付文字列
 * @returns 相対時間（例: 3日前）
 */
export function formatRelativeDateJapanese(dateString: string): string {
  if (!dateString) return "";
  
  const publishedDate = new Date(dateString);
  const now = new Date();
  
  if (isNaN(publishedDate.getTime())) return "";
  
  const diffInSeconds = Math.floor((now.getTime() - publishedDate.getTime()) / 1000);
  
  if (diffInSeconds < 60) {
    return `${diffInSeconds}秒前`;
  } else if (diffInSeconds < 3600) {
    return `${Math.floor(diffInSeconds / 60)}分前`;
  } else if (diffInSeconds < 86400) {
    return `${Math.floor(diffInSeconds / 3600)}時間前`;
  } else if (diffInSeconds < 2592000) {
    return `${Math.floor(diffInSeconds / 86400)}日前`;
  } else if (diffInSeconds < 31536000) {
    return `${Math.floor(diffInSeconds / 2592000)}ヶ月前`;
  } else {
    return `${Math.floor(diffInSeconds / 31536000)}年前`;
  }
}
