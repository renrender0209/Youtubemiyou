import { useState, useEffect } from "react";
import VideoItem from "../components/VideoItem";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function Home() {
  // 日本のトレンド動画を取得
  const { data, isLoading, error } = useQuery({
    queryKey: ['/api/trending', 'JP'],
    queryFn: () => apiRequest<{videos: any[]}>('/api/trending?region=JP&limit=24')
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mt-4">
        {[...Array(12)].map((_, i) => (
          <div key={i} className="rounded-lg overflow-hidden">
            <div className="aspect-video bg-gray-200 animate-pulse"></div>
            <div className="p-2">
              <div className="h-4 bg-gray-200 animate-pulse rounded w-3/4 mt-2"></div>
              <div className="h-3 bg-gray-200 animate-pulse rounded w-1/2 mt-2"></div>
              <div className="h-3 bg-gray-200 animate-pulse rounded w-1/4 mt-1"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="text-center">
          <h2 className="text-xl font-bold mb-2">動画の読み込みに失敗しました</h2>
          <p className="text-text-secondary">後でもう一度お試しください</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mt-4 mb-6">日本の人気動画</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {data && data.videos && data.videos.map((video: any) => (
          <VideoItem key={video.videoId} video={video} />
        ))}
      </div>
    </div>
  );
}
