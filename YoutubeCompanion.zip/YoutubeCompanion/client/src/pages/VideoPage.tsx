import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import VideoPlayer from "../components/VideoPlayer";
import VideoDescription from "../components/VideoDescription";
import RelatedVideos from "../components/RelatedVideos";
import CommentsSection from "../components/CommentsSection";
import { useEffect } from "react";
import { getVideoById, VideoOptions } from "../lib/youtube";

export default function VideoPage() {
  const { id } = useParams();
  const [location] = useLocation();
  
  // URLからクエリパラメータを取得
  const searchParams = new URLSearchParams(window.location.search);
  const mode = searchParams.get('mode');
  const server = searchParams.get('server');
  const source = searchParams.get('source');
  
  // オプションを構築
  const options: VideoOptions = {};
  if (mode) options.mode = mode;
  if (server) options.serverUrl = server;
  if (source) options.preferredServer = source;
  
  // クエリキーに選択したサーバーオプションを含める
  const queryKey = [`/api/videos/${id}`, options];
  
  // カスタムクエリ関数を使用して、指定されたサーバーオプションで動画を取得
  const { data, isLoading, error } = useQuery({
    queryKey,
    queryFn: () => id ? getVideoById(id, options) : Promise.reject(new Error('No video ID')),
  });

  // Set page title when video data is loaded
  useEffect(() => {
    if (data && data.videoTitle) {
      document.title = `${data.videoTitle} - YouTube Viewer`;
    }
    return () => {
      document.title = "YouTube Viewer";
    };
  }, [data]);

  if (isLoading) {
    return (
      <div className="mt-4">
        <div className="aspect-video bg-gray-200 animate-pulse rounded"></div>
        <div className="h-8 bg-gray-200 animate-pulse rounded mt-4 w-3/4"></div>
        <div className="h-4 bg-gray-200 animate-pulse rounded mt-2 w-1/2"></div>
        <div className="flex mt-4">
          <div className="h-12 w-12 bg-gray-200 animate-pulse rounded-full"></div>
          <div className="ml-3">
            <div className="h-5 bg-gray-200 animate-pulse rounded w-40"></div>
            <div className="h-4 bg-gray-200 animate-pulse rounded mt-1 w-24"></div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !id) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="text-center">
          <h2 className="text-xl font-bold mb-2">Video not found</h2>
          <p className="text-text-secondary">The video you're looking for might have been removed or is unavailable</p>
        </div>
      </div>
    );
  }

  return (
    <div className="mt-4">
      {data && (
        <>
          <VideoPlayer videoData={data} />
          <VideoDescription videoData={data} />
          <CommentsSection videoId={id} comments={data.comments} />
          <RelatedVideos videoId={id} />
        </>
      )}
    </div>
  );
}
