import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import VideoItem from "../components/VideoItem";
import { useEffect } from "react";

export default function SearchResults() {
  const { query } = useParams();
  const decodedQuery = decodeURIComponent(query || "");

  const { data, isLoading, error } = useQuery({
    queryKey: [`/api/search?q=${encodeURIComponent(decodedQuery)}`],
  });
  
  useEffect(() => {
    document.title = `${decodedQuery} - Search - YouTube Viewer`;
    return () => {
      document.title = "YouTube Viewer";
    };
  }, [decodedQuery]);

  if (isLoading) {
    return (
      <div className="mt-4">
        <h1 className="text-2xl font-bold mb-6">Searching for "{decodedQuery}"...</h1>
        <div className="space-y-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="flex flex-col sm:flex-row gap-4">
              <div className="sm:w-64 aspect-video bg-gray-200 animate-pulse rounded"></div>
              <div className="flex-1">
                <div className="h-6 bg-gray-200 animate-pulse rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-gray-200 animate-pulse rounded w-1/2 mb-1"></div>
                <div className="h-4 bg-gray-200 animate-pulse rounded w-1/3"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="text-center">
          <h2 className="text-xl font-bold mb-2">Search failed</h2>
          <p className="text-text-secondary">Unable to search for "{decodedQuery}"</p>
        </div>
      </div>
    );
  }

  return (
    <div className="mt-4">
      <h1 className="text-2xl font-bold mb-6">Search results for "{decodedQuery}"</h1>
      {data && data.videos && data.videos.length > 0 ? (
        <div className="space-y-4">
          {data.videos.map((video: any) => (
            <VideoItem key={video.videoId} video={video} layout="horizontal" />
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <h3 className="text-xl mb-2">No results found</h3>
          <p className="text-text-secondary">Try different keywords or check your spelling</p>
        </div>
      )}
    </div>
  );
}
